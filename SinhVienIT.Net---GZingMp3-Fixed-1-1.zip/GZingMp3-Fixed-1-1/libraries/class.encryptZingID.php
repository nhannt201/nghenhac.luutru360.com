<?php defined('K_SEC') or die('No direct script access.');

class Encrypt_ZingID {
    
    public $_ID = '';
    private $_zingBitDefault = array(1, 0, 8, 0, 10);
    private $_zingBit = array();
    private $_chartKey = array(
        'arrayChar' => 'GHmn|LZk|DFbv|BVd|ASlz|QWp|ghXC|Nas|Jcx|ERui|Tty',
        'chartA' => '0IWOUZ6789ABCDEF',
        'chartB' => '0123456789ABCDEF'
    );

    public function _getEncryptedID(){
        $this->_zingBit = array(10, 1, 2, 8, 10, 2, 0, 1, 0);
        $zingKey = array_map(array($this, '_splitZingID'),$this->_getZingID());
        $zingKey = implode('',$zingKey);
        $zingKey = intval($zingKey, 16) - 307843200;
        $splitKey = str_split($zingKey,1);
        for($i=0;$i<=count($splitKey);$i++){
            array_push($this->_zingBitDefault,$splitKey[$i]);
        }
        array_pop($this->_zingBitDefault);
        for($i=0;$i<=count($this->_zingBit);$i++){
            array_push($this->_zingBitDefault,$this->_zingBit[$i]);
        }
        array_pop($this->_zingBitDefault);
        $zingKey = implode('',array_map(array($this, '_splitZingKey'),$this->_zingBitDefault));
        return $zingKey;
    }
    
    private function _getZingID(){
        if($this->_ID != ''){
            for($i=0;$i<=strlen($this->_ID);$i++){
                $zingID[] = $this->_ID[$i];
            }
            array_pop($zingID);
            return $zingID;
        }
    }
    
    private function _splitZingKey($arrayKey){
        $arrayA = explode('|',$this->_chartKey['arrayChar']);
        return $arrayA[$arrayKey][rand(0,count($arrayA[$arrayKey]))];
    }

    private function _splitZingID($_idArray){
        return $this->_chartKey['chartB'][strpos($this->_chartKey['chartA'], $_idArray)];
    }
}
<?php defined('K_SEC') or die('No direct script access.');

class K_Cache {
	
	const DEFAULT_EXPIRE = 3600;
	
	/**
	* @var K_Cache instances
	*/
	public static $instances = null;
	
	public static function instance(){
		
		require_once LIB_DIR . "cache/file.php";
		
		// Create a new cache type instance
		K_Cache::$instances = new K_Cache_File;

		// Return the instance
		return K_Cache::$instances;
	}

	/**
	 * Replaces troublesome characters with underscores.
	 *
	 *     // Sanitize a cache id
	 *     $id = $this->_sanitize_id($id);
	 *
	 * @param   string  $id  id of cache to sanitize
	 * @return  string
	 */
	protected function _sanitize_id($id){
		// Change slashes and spaces to underscores
		return str_replace(array('/', '\\', ' '), '_', $id);
	}
}
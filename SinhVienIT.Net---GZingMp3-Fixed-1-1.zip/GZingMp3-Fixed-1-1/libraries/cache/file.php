<?php defined('K_SEC') or die('No direct script access.');

class K_Cache_File extends K_Cache {

	protected $_cacheDir = 'cache';
    
    protected $_ignore_on_delete = array(
		'.htaccess'
	);


    function __construct() {
        $directory = ROOT . $this->_cacheDir;
        $this->_cacheDir = new SplFileInfo($directory);
    }
    
	protected static function filename($string){
		return sha1($string).'cache';
	}
	
	public function get($id,$default = null){
        $filename = K_Cache_File::filename($this->_sanitize_id($id));
        $directory = $this->_resolve_directory($filename);
		try{
			// Open file
			$file = new SplFileInfo($directory.$filename);
			// If file does not exist
			if (!$file->isFile()){
				// Return default value
				return $default;
			}else{
				// Open the file and parse data
				$created  = $file->getMTime();
				$data     = $file->openFile();
				$lifetime = $data->fgets();
				// If we're at the EOF at this point, corrupted!
				if ($data->eof()){
					throw new Exception(__METHOD__.' corrupted cache file!');
				}
				$cache = '';
				while ($data->eof() === FALSE){
					$cache .= $data->fgets();
				}

				// Test the expiry
				if (($created + (int) $lifetime) < time()){
					// Delete the file
					$this->_delete_file($file, NULL, TRUE);
					return $default;
				}else{
					return unserialize($cache);
				}
			}
		}catch (ErrorException $e){
			// Handle ErrorException caused by failed unserialization
			if ($e->getCode() === E_NOTICE){
				throw new Exception(__METHOD__.' failed to unserialize cached object with message : '.$e->getMessage());
			}
			// Otherwise throw the exception
			throw $e;
		}
    }
    
	public function set($id, $data, $lifetime = NULL){
		$filename = K_Cache_File::filename($this->_sanitize_id($id));
		$directory = $this->_resolve_directory($filename);

		// If lifetime is NULL
		if ($lifetime === NULL){
			// Set to the default expiry
			$lifetime = K_Cache::DEFAULT_EXPIRE;
		}

		// Open directory
		$dir = new SplFileInfo($directory);

		// If the directory path is not a directory
		if (!$dir->isDir()){
			// Create the directory
			if (!mkdir($directory, 0777, TRUE)){
				throw new Exception(__METHOD__.' unable to create directory : :directory', array(':directory' => $directory));
			}
			// chmod to solve potential umask issues
			chmod($directory, 0777);
		}
		// Open file to inspect
		$resouce = new SplFileInfo($directory.$filename);
		$file = $resouce->openFile('w');

		try{
			$data = $lifetime."\n".serialize($data);
			$file->fwrite($data, strlen($data));
			return (bool) $file->fflush();
		}catch (ErrorException $e){
			// If serialize through an error exception
			if ($e->getCode() === E_NOTICE){
				// Throw a caching error
				throw new Exception(__METHOD__.' failed to serialize data for caching with message : '.$e->getMessage());
			}
			// Else rethrow the error exception
			throw $e;
		}
	}
    
	/**
	 * Delete a cache entry based on id
	 *
	 *     // Delete 'foo' entry from the file group
	 *     Cache::instance()->delete('foo');
	 *
	 * @param   string   $id  id to remove from cache
	 * @return  boolean
	 */
	public function delete($id){
		$filename = K_Cache_File::filename($this->_sanitize_id($id));
		$directory = $this->_resolve_directory($filename);
		return $this->_delete_file(new SplFileInfo($directory.$filename), NULL, TRUE);
	}
    
	/**
	 * Delete all cache entries.
	 *
	 * Beware of using this method when
	 * using shared memory cache systems, as it will wipe every
	 * entry within the system for all clients.
	 *
	 *     // Delete all cache entries in the file group
	 *     K_Cache::instance()->delete_all();
	 *
	 * @return  boolean
	 */
	public function delete_all(){
		return $this->_delete_file($this->_cacheDir, TRUE);
	}
    
	/**
	 * Deletes files recursively and returns FALSE on any errors
	 *
	 *     // Delete a file or folder whilst retaining parent directory and ignore all errors
	 *     $this->_delete_file($folder, TRUE, TRUE);
	 *
	 * @param   SplFileInfo  $file                     file
	 * @param   boolean      $retain_parent_directory  retain the parent directory
	 * @param   boolean      $ignore_errors            ignore_errors to prevent all exceptions interrupting exec
	 * @param   boolean      $only_expired             only expired files
	 * @return  boolean
	 * @throws  Exception
	 */
	protected function _delete_file(SplFileInfo $file, $retain_parent_directory = FALSE, $ignore_errors = FALSE, $only_expired = FALSE){
		// Allow graceful error handling
		try{
			// If is file
			if ($file->isFile()){
				try{
					// Handle ignore files
					if (in_array($file->getFilename(), $this->_ignore_on_delete)){
						$delete = FALSE;
					}elseif($only_expired === FALSE){// If only expired is not set
						// We want to delete the file
						$delete = TRUE;
					}else{// Otherwise...
						// Assess the file expiry to flag it for deletion
						$json = $file->openFile('r')->current();
						$data = json_decode($json);
						$delete = $data->expiry < time();
					}

					// If the delete flag is set delete file
					if ($delete === TRUE){
						return unlink($file->getRealPath());
                    }else{
						return FALSE;
                    }
				}catch (ErrorException $e){
					// Catch any delete file warnings
					if ($e->getCode() === E_WARNING){
						throw new Exception(__METHOD__.' failed to delete file : :file', array(':file' => $file->getRealPath()));
					}
				}
			}elseif ($file->isDir()){// Else, is directory
				// Create new DirectoryIterator
				$files = new DirectoryIterator($file->getPathname());

				// Iterate over each entry
				while ($files->valid()){
					// Extract the entry name
					$name = $files->getFilename();

					// If the name is not a dot
					if ($name != '.' AND $name != '..'){
						// Create new file resource
						$fp = new SplFileInfo($files->getRealPath());
						// Delete the file
						$this->_delete_file($fp);
					}
					// Move the file pointer on
					$files->next();
				}
				// If set to retain parent directory, return now
				if ($retain_parent_directory){
					return TRUE;
				}
				try{
					// Remove the files iterator
					// (fixes Windows PHP which has permission issues with open iterators)
					unset($files);
					// Try to remove the parent directory
					return rmdir($file->getRealPath());
				}catch (ErrorException $e){
					// Catch any delete directory warnings
					if ($e->getCode() === E_WARNING){
						throw new Exception(__METHOD__.' failed to delete directory : :directory', array(':directory' => $file->getRealPath()));
					}
					throw $e;
				}
			}else{
				// We get here if a file has already been deleted
				return FALSE;
			}
		}catch (Exception $e){// Catch all exceptions
			// If ignore_errors is on
			if ($ignore_errors === TRUE){
				// Return
				return FALSE;
			}
			// Throw exception
			throw $e;
		}
	}
	
	/**
	 * Resolves the cache directory real path from the filename
	 *
	 *      // Get the realpath of the cache folder
	 *      $realpath = $this->_resolve_directory($filename);
	 *
	 * @param   string  $filename  filename to resolve
	 * @return  string
	 */
	protected function _resolve_directory($filename){
		return $this->_cacheDir->getRealPath().DIRECTORY_SEPARATOR.$filename[0].$filename[1].DIRECTORY_SEPARATOR;
	}
    
	/**
	 * Makes the cache directory if it doesn't exist. Simply a wrapper for
	 * `mkdir` to ensure DRY principles
	 *
	 * @link    http://php.net/manual/en/function.mkdir.php
	 * @param   string    $directory
	 * @param   integer   $mode
	 * @param   boolean   $recursive
	 * @param   resource  $context
	 * @return  SplFileInfo
	 * @throws  Exception
	 */
	protected function _make_directory($directory, $mode = 0777, $recursive = FALSE, $context = NULL){
		if (!mkdir($directory, $mode, $recursive, $context)){
			throw new Exception('Failed to create the defined cache directory : :directory', array(':directory' => $directory));
		}
		chmod($directory, $mode);
		return new SplFileInfo($directory);
	}
}
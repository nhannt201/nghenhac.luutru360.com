<?php defined('K_SEC') or die('No direct script access.');

class NC_CURL{
    
    var $ch;
    var $debug = false;
    var $error_msg;
    
    /**
     * 
     * @param type $debug
     */
    function NC_CURL($debug = false){
        $this->debug = $debug;
        $this->init();
    }
    
    /**
     * 
     */
    function init(){
		global $config;
		if($config['is_curl'] != false){
			$this->ch = curl_init();
			curl_setopt($this->ch, CURLOPT_FAILONERROR, true);
			curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, true);
			//curl_setopt($this->ch, CURLOPT_ENCODING , 'gzip, deflate');
			curl_setopt($this->ch, CURLOPT_ENCODING , 'utf-8');
			curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, 0);
		}

    }
    
    /**
     * 
     * @param type $username
     * @param type $password
     */
    function set_credentials($username,$password){
        curl_setopt($this->ch, CURLOPT_USERPWD, "$username:$password");
    }
    
    /**
     * 
     * @param type $referrer_url
     */
    function set_referrer($referrer_url){
        curl_setopt($this->ch, CURLOPT_REFERER, $referrer_url);
    }
    
    /**
     * 
     * @param type $useragent
     */
    function set_user_agent($useragent){
        curl_setopt($this->ch, CURLOPT_USERAGENT, $useragent);
    }
    
    /**
     * 
     * @param type $value
     */
    function include_response_headers($value){
        curl_setopt($this->ch, CURLOPT_HEADER, $value);
    }
    
    /**
     * 
     * @param type $proxy
     */
    function set_proxy($proxy){
        curl_setopt($this->ch, CURLOPT_PROXY, $proxy);
    }
    
    /**
     * 
     * @param type $url
     * @param type $postdata
     * @param type $ip
     * @param type $timeout
     * @return boolean
     */
    function send_post_data($url, $postdata, $ip=null, $timeout=15){
        curl_setopt($this->ch, CURLOPT_URL,$url);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER,true);
        if($ip){
            if($this->debug){
                echo "Binding to ip $ip\n";
            }
            curl_setopt($this->ch,CURLOPT_INTERFACE,$ip);
        }
        curl_setopt($this->ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($this->ch, CURLOPT_POST, true);
        $post_array = array();
        if(is_array($postdata)){		
            foreach($postdata as $key=>$value){
                $post_array[] = urlencode($key) . "=" . urlencode($value);
            }
            $post_string = implode("&",$post_array);
            if($this->debug){
                echo "Url: $url\nPost String: $post_string\n";
            }
        }else{
            $post_string = $postdata;
        }
        curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post_string);
        $result = curl_exec($this->ch);
        if(curl_errno($this->ch)){
            if($this->debug){
                echo "Error Occured in Curl\n";
                echo "Error number: " .curl_errno($this->ch) ."\n";
                echo "Error message: " .curl_error($this->ch)."\n";
            }
            return false;
        }else{
            return $result;
        }
    }
    
    /**
     * 
     * @param type $url
     * @param type $ip
     * @param type $timeout
     * @return boolean
     */
    function views_source($url, $ip=null, $timeout=5){
        curl_setopt($this->ch, CURLOPT_URL,$url);
        curl_setopt($this->ch, CURLOPT_HTTPGET,true);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER,true);
        if($ip){
            if($this->debug){
                echo "Binding to ip $ip\n";
            }
            curl_setopt($this->ch,CURLOPT_INTERFACE,$ip);
        }
        curl_setopt($this->ch, CURLOPT_TIMEOUT, $timeout);
        $result = curl_exec($this->ch);
        if(curl_errno($this->ch)){
            if($this->debug)
            {
                echo "Error Occured in Curl\n";
                echo "Error number: " .curl_errno($this->ch) ."\n";
                echo "Error message: " .curl_error($this->ch)."\n";
            }
            return false;
        }else{
            return $result;
        }
        $httpcode = $this->get_http_response_code();
        if($httpcode>=200 && $httpcode<300){
                return true;
        }else{
                return false;
        }
        $this->close_curl();
    }
    
    /**
     * 
     * @param type $url
     * @param type $ip
     * @param type $timeout
     * @return type
     */
    function get_location($url, $ip=null, $timeout=15){
        curl_setopt($this->ch, CURLOPT_URL , $url);
        curl_setopt($this->ch, CURLOPT_HEADER , true);
        //curl_setopt($this->ch, CURLOPT_NOBODY , false);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER , true);
        curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, false); //don't follow redirects
        if($ip){
            if($this->debug){
                echo "Binding to ip $ip\n";
            }
            curl_setopt($this->ch,CURLOPT_INTERFACE,$ip);
        }
        curl_setopt($this->ch, CURLOPT_TIMEOUT , $timeout); 
        $result = curl_exec($this->ch);
        $curl_info = curl_getinfo($this->ch);
        $headers = substr($result, 0, $curl_info['header_size']);
        preg_match("!\r\n(?:Location|URI): *(.*?) *\r\n!", $headers, $matches);
        $url = $matches[1];
        return trim($url);
    }
    
    
    /**
     * 
     * @param type $cookie_file
     */
    function store_cookies($cookie_file){
        curl_setopt ($this->ch, CURLOPT_COOKIEJAR, $cookie_file);
        curl_setopt ($this->ch, CURLOPT_COOKIEFILE, $cookie_file);
    }
    
    /**
     * 
     * @param type $cookie
     */
    function set_cookie($cookie){		
        curl_setopt ($this->ch, CURLOPT_COOKIE, $cookie);
    }
    
    /**
     * 
     * @return type
     */
    function get_effective_url(){
        return curl_getinfo($this->ch, CURLINFO_EFFECTIVE_URL);
    }
    
    /**
     * 
     * @return type
     */
    function get_http_response_code(){
        return curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
    }
    
    /**
     * 
     * @param type $url
     * @return boolean
     */
    function validate($url){
        curl_setopt ($this->ch, CURLOPT_URL, $url);
        //curl_setopt ($this->ch, CURLOPT_RETURNTRANSFER, 1);
        //curl_setopt ($this->ch, CURLOPT_VERBOSE, false);
        //curl_setopt ($this->ch, CURLOPT_TIMEOUT, 15);
        $page = curl_exec($this->ch);
        $httpcode = $this->get_http_response_code();
        if($httpcode == 200 || $httpcode == 302 || $httpcode == 304 || $httpcode == 400){
                return true;
        }else{
                return false;
        }
    }
    
    function checkUrlExists($url){
        if(filter_var($url, FILTER_VALIDATE_URL) === FALSE){
            return false;
        }else{
            return true;
        }
    }
    
    /**
     * 
     * @return string
     */
    function get_error_msg(){
        $err = "Error number: " .curl_errno($this->ch) ."\n";
        $err .="Error message: " .curl_error($this->ch)."\n";
        return $err;
    }
    
    /**
     * 
     */
    function close_curl(){
        curl_close($this->ch);
    }
}
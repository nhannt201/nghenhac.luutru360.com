<?php defined('K_SEC') or die('No direct script access.');

class Modules {
    
    public function _loadModules($path = '',$name = '', $action = 'index'){
        if(!empty($path)){
            $filePath = MOD_DIR . $path . DIRECTORY_SEPARATOR . $name . DIRECTORY_SEPARATOR . $action . EXT;
        }else{
            $filePath = MOD_DIR . $name . DIRECTORY_SEPARATOR . $action . EXT;
        }
        try{
            if(!file_exists($filePath)){
                throw new Exception('File not found: '. $filePath);
            }else{
                require_once $filePath;
            }
        }catch(Exception $e){
            echo 'Error!: ' .$e->getMessage();
        }
    }
}
<?php

class Zing extends NC_CURL {

	public $_query = null;
	private $_bxhConfig = array(
		'ID' => array(
			'vietnam' 	=> 'IWZ9Z08I',
			'aumy' 		=> 'IWZ9Z0BW',
			'hanquoc' 	=> 'IWZ9Z0BO',
		),
		'URL' => 'http://mp3.zing.vn/ajax/block-charts/get-song-charts?id=%ID',
		'MATCH' => '/<h3[^>]*(?<!_)><a[^>]*(?<!_)href="\/([a-z_-]+)\/([A-z0-9_-]+)\/([A-Z0-9]+).html"[^>]*(?<!_)title="(.*?)"/i'
	);
	private $_zingSearchConfig = array(
		'URL' => 'http://m.mp3.zing.vn/tim-kiem/bai-hat.html?q=%query&search_type=bai-hat&filter=2&search_sort=total_play'
	);
	
	public function _getBXH(){
	
		// Viewsource
		$source = array();
		for($i=0;$i<=2;$i++){
			switch($i){
				case 0:
					$country = 'vietnam';
					break;
				case 1:
					$country = 'aumy';
					break;
				case 2:
					$country = 'hanquoc';
					break;
			}
			$source[] = $this->_getViewSource($this->_getBxhURL($country));
		}
		
		// Json decode
		$jsonResultVN = json_decode($source[0]);
		$jsonResultEA = json_decode($source[1]);
		$jsonResultHQ = json_decode($source[2]);
		
		// Get ID,Name,Title
		$countResultVN = preg_match_all($this->_bxhConfig['MATCH'],$jsonResultVN->result,$_bxhVN);
		$countResultEA = preg_match_all($this->_bxhConfig['MATCH'],$jsonResultEA->result,$_bxhEA);
		$countResultHQ = preg_match_all($this->_bxhConfig['MATCH'],$jsonResultHQ->result,$_bxhHQ);
		
		$result = array(
			'count' => $countResultVN,
			'bxh_vietnam' => array(
				'ID' => $_bxhVN[3],
				'TITLE' => $_bxhVN[4],
				'NAME' => $_bxhVN[2],
			),
			'bxh_aumy' => array(
				'ID' => $_bxhEA[3],
				'TITLE' => $_bxhEA[4],
				'NAME' => $_bxhEA[2],
			),
			'bxh_hanquoc' => array(
				'ID' => $_bxhHQ[3],
				'TITLE' => $_bxhHQ[4],
				'NAME' => $_bxhHQ[2],
			),
		);
		return $result;
	}
	
	public function _getListBXH($country = null){
		$bxh = $this->_getBXH();
		$html = '';
		if($country != null){
			for($i=1;$i<=$bxh['count'];$i++){
				$html .= '<li><a id="item_song_'.$bxh['bxh_'.$country]['ID'][$i-1].'" title="'.$bxh['bxh_'.$country]['TITLE'][$i-1].'" href="javascript:;" rel="'.$bxh['bxh_'.$country]['NAME'][$i-1].'/'.$bxh['bxh_'.$country]['ID'][$i-1].'" onclick="KScript.ajax.playMusic(\''.$bxh['bxh_'.$country]['ID'][$i-1].'\');">'.$bxh['bxh_'.$country]['TITLE'][$i-1].'</a></li>';
			}
		}else{
			for($i=1;$i<=$bxh['count'];$i++){
				$html .= '<li><a id="item_song_'.$bxh['bxh_vietnam']['ID'][$i-1].'" title="'.$bxh['bxh_vietnam']['TITLE'][$i-1].'" href="javascript:;" rel="'.$bxh['bxh_vietnam']['NAME'][$i-1].'/'.$bxh['bxh_vietnam']['ID'][$i-1].'" onclick="KScript.ajax.playMusic(\''.$bxh['bxh_vietnam']['ID'][$i-1].'\');">'.$bxh['bxh_vietnam']['TITLE'][$i-1].'</a></li>';
			}
		}
		return $html;
	}
	
	public function _getSearch(){
		if($this->_query != null){
			$sourceSearch = $this->_getViewSource($this->_getSearchURL());
			$countSong = preg_match_all('/<a href="\/bai-hat\/([A-z0-9_-]+)\/([A-Z0-9]+).html" class="content-items">/i',$sourceSearch,$songNameID);
			$countSongTitle = preg_match_all('/<h3>(.*?)<\/h3>[^>]*(?<!_)<h4>(.*?)<span>HQ<\/span><\/h4>/i',$sourceSearch,$songTitle);
			
			if($countSong != 0 && $countSongTitle != 0){
				$html = '';
				for($i=1;$i<=$countSong;$i++){
					$html .= '<li><a id="item_song_'.$songNameID[2][$i-1].'" title="'.$songTitle[1][$i-1].' - '.$songTitle[2][$i-1].'" href="javascript:;" rel="'.$songNameID[1][$i-1].'/'.$songNameID[2][$i-1].'" onclick="KScript.ajax.playMusic(\''.$songNameID[2][$i-1].'\');">'.$songTitle[1][$i-1].' - '.$songTitle[2][$i-1].'</a></li>';
				}
			}else{
				$html = false;
			}
			
			
			return $html;
		}
	}
	
	
	
	public function _getSongTitle($EncryptID = null){
		if($EncryptID != null){
			$sourceXmlSong = $this->_getViewSource('http://m.mp3.zing.vn/xml/song/'.$EncryptID);
			$jsonInfoSong = json_decode($sourceXmlSong);
			return $jsonInfoSong->data[0]->title . ' - ' . $jsonInfoSong->data[0]->performer;
		}
	}
	
	private function _getBxhURL($country = null){
		if($country != null){
			return str_replace("%ID",$this->_bxhConfig['ID'][$country],$this->_bxhConfig['URL']);
		}else{
			return str_replace("%ID",$this->_bxhConfig['ID']['vietnam'],$this->_bxhConfig['URL']);
		}
	}
	
	private function _getSearchURL(){
		if($this->_query != null){
			return str_replace("%query",$this->_query,$this->_zingSearchConfig['URL']);
		}
	}
	
	private function _getViewSource($url){
		global $config;
		if($config['is_curl'] != false){
			return $this->views_source($url);
		}else{
			return file_get_contents($url);
		}
	}
	
}
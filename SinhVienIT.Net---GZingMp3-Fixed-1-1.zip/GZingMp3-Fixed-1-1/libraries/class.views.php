<?php defined('K_SEC') or die('No direct script access.');

class View {

    public $_pathView = 'views';
    public $_layout = 'template';
    public $_blockFolder = 'block';
	
    function View($path = '',$name = '',$data = '',$isLayout = true){
        
        $pathView = $this->_pathView . DIRECTORY_SEPARATOR;
        
        if(!empty($path)){
            $blockFile = $pathView . $path . DIRECTORY_SEPARATOR . $name . EXT;
        }else{
            $blockFile = $pathView . $this->_blockFolder . DIRECTORY_SEPARATOR . $name . EXT;
        }
        try{
            if(!file_exists($blockFile)){
                throw new Exception('File not found: '. $filePath);
            }else{
                if($data != ''){
                    if(is_array($data)){
                        extract($data);
                    }
                }
                if($isLayout == true){
                    require_once $pathView . $this->_layout . EXT;
                }else{
                    require_once $blockFile;
                }
            }
        }catch(Exception $e){
            echo 'Error!: ' .$e->getMessage();
        }
    }

}
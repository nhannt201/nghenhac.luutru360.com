<?php defined('K_SEC') or die('No direct script access.');

function _checkReferer(){
    $site = parse_url(SITEURL);
    if(strpos($_SERVER['HTTP_REFERER'], $site['host'])===false){
        return false;
    }else{
        return true;
    }
}

function _getHost(){
    $url = parse_url(SITEURL);
    return $url['host'];
}

function _checkIP($IP){
    $hash = md5($_SERVER['REMOTE_ADDR'].K_CODE);
    return $IP==$hash;
}

function findStr($text ,$arr=array()){
    $chr = array();
    foreach($arr as $arr1){
        $chr[] = strpos($text,$arr1,0);
    }
    if(empty($chr)){
        return false;
    }
    return min($chr);
}

function getStr($source, $start, $end=''){
	if(!$start){
		$str = explode($end, $source);
		return $str[0];
	}else{
		$str = explode($start, $source);
		if($end){		
			$str = explode($end, $str[1]);
			return $str[0];
		}else
			return $str[1];
	}
}
function getmicrotime($e = 0){
	list($u, $s) = explode(' ',time()/ 1000 * 1000);
	return bcadd($u, $s, $e);
}

function _getListDL($arrSong,$bit){
    for($i=0;$i<=count($arrSong);$i++){
        $songDL .= '<li>'.$arrSong[$i][$bit].'</li>';
    }
    return $songDL;
}

function _getListXML($arrSong){
    for($i=0;$i<=count($arrSong);$i++){
        $listTrack .= '
            <track>
                <title>'.$arrSong[$i]['name'].'</title>
                <location>'.$arrSong[$i]['link'].'</location>
            </track>
        ';
    }
    return $listTrack;
}

function subChar($text, $length) {  
    $length = abs((int)$length);  
    if(strlen($text) > $length) {  
       $text = preg_replace("/^(.{1,$length})(\s.*|$)/s", '\\1...', $text);  
    }  
    return($text);  
}
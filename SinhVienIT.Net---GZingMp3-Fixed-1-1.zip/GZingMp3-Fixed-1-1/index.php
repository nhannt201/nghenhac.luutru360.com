<?php

define('K_SEC', true);
define('SELF', pathinfo(__FILE__, PATHINFO_BASENAME));
define('ROOT', str_replace(SELF, '', __FILE__));

$lib = 'libraries';
$mod = 'modules';
$pub = 'public';


define('EXT', '.php');

if(realpath($lib) !== false){
	$lib = realpath($lib).'/';
}
if(realpath($mod) !== false){
	$mod = realpath($mod).'/';
}
if(realpath($pub) !== false){
	$pub = realpath($pub).'/';
}
$lib = rtrim($lib, '/').'/';
$mod = rtrim($mod, '/').'/';
$pub = rtrim($pub, '/').'/';
if(!is_dir($lib)){
    exit("Folder not found: {$lib}".SELF);
}else{
    define('LIB_DIR', str_replace("\\", "/", $lib));
}
if(!is_dir($mod)){
    exit("Folder not found: {$mod}".SELF);
}else{
    define('MOD_DIR', str_replace("\\", "/", $mod));
}
if(!is_dir($pub)){
    exit("Folder not found: {$pub}".SELF);
}else{
    define('PUB_DIR', str_replace("\\", "/", $pub));
}
unset($lib, $mod, $pub);
require_once ROOT . 'config'. EXT;
require_once LIB_DIR . 'class.curl'. EXT;
require_once LIB_DIR . 'functions'. EXT;
require_once LIB_DIR . 'class.modules' . EXT;
require_once LIB_DIR . 'class.views'. EXT;

$mod = isset($_GET['modules']) ? $_GET['modules'] : '';
$act = isset($_GET['action']) ? $_GET['action'] : 'index';
if($mod){
    $modules = new Modules;
    $modules->_loadModules('', $mod,$act);
}else{
    $kView = new View('', 'home',$data);
}
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function(){
    
	KScript.ajax.bxhMP3();
	
	//Change id
	KScript.changeID();
	
    //Download & Search mp3
    $('button#txtGet').click(function(){
		KScript.type = $("#txtType").val();
        KScript.ajax();
    });
});

function _submit(){
	KScript.type = $("#txtType").val();
	KScript.ajax();
}
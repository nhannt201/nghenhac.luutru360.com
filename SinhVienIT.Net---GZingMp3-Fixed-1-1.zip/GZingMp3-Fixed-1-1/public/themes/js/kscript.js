/**
 * KScript v1.1.0
 */
var KScript = {};
var type;
var query;

KScript.ajax = function(type){
	if(KScript.type == 'download'){
		this.ajax.downloadMP3();
	}else if(KScript.type == 'search'){
		this.ajax.searchMP3();
	}else{
		alert('Xin vui lòng nhập từ khoá hoặc liên kết đến bài hát bạn muốn nghe.');
		return false;
	}
};

KScript.changeID = function() {
	$(".txtInputMusic").keyup(function(e) {
		$findString = this.value.match(/http:\/\/mp3.zing.vn\/([a-z_-]+)\/([A-z0-9_-]+)\/([A-Z0-9]+).html/i);
		if($findString != null){
			$("#txtType").val('download');
			$(".txtButtonMusic").html('<i class="icon-download"></i> Nghe & Tải');
		}else{
			$("#txtType").val('search');
			$(".txtButtonMusic").html('<i class="icon-search"></i> Tìm kiếm');
		}
	});
};

KScript.ajax.bxhMP3 = function(){
	$.ajax({
		type: "GET",
		url: ROOT + "/index.php?modules=zing&action=song&type=bxh",
		dataType: "json",
		success: function(data){
			KScript.ajax.showBXH(data);
		},
		error: function (xhr, status, error) {
			alert('Đã xảy ra lỗi khi lấy dữ liệu.');
		}
	});
};

KScript.ajax.showBXH = function(data){
	if(data.status != false){
		$(".listbxh_vietnam").html(data.vietnam);
		$(".listbxh_aumy").html(data.aumy);
		$(".listbxh_hanquoc").html(data.hanquoc);
		return false;
	}else{
		return false;
	}
};

KScript.ajax.downloadMP3 = function(){
	var link = $(".txtInputMusic").val();
	$.ajax({
		type: "POST",
		url: ROOT + "/index.php?modules=zing&action=song&type=get",
		dataType: "json",
		data: {
			link: link.split('/'),
		},
		success: function(data){
			if(data.status != false){
				if($("#box_player").show()){
					$('video, audio').each(function() {
						$(this)[0].player.pause();		  
					});
					$("#box_player").show();
					$("#music-title").html('Bạn đang nghe bài hát: <span title="' + data.title + '">' + data.title + '<span>');
					$(".playermusic").html(data.source);
				}
			}
		},
		error: function (xhr, ajaxOptions, thrownError) {
			alert('Đã xảy ra lỗi khi lấy dữ liệu.');
		}
	});
    return false;
};

KScript.ajax.searchMP3 = function(){
	var query = $(".txtInputMusic").val();
	$.ajax({
		type: "POST",
		url: ROOT + "/index.php?modules=zing&action=search",
		dataType: "json",
		data: {
			query: query,
		},
		success: function(data){
			if(data.status != false){
				if($("#box_search").show()){
					$("#box_search").show();
					$("#search-title").html('Từ khoá: <span title="' + data.title + '">' + data.title + '<span>');
					$(".item_search").html(data.source);
				}
			}
		},
		error: function (xhr, ajaxOptions, thrownError) {
			alert('Đã xảy ra lỗi khi lấy dữ liệu.');
		}
	});
    return false;
};

KScript.ajax.playMusic = function(id){
	var name_id = $("a#item_song_" + id).attr('rel');
	var title = $("a#item_song_" + id).html();
	$.ajax({
		type: "POST",
		url: ROOT + "/index.php?modules=zing&action=song&type=play_song",
		dataType: "json",
		data: {
			name_id: name_id.split('/'),
			title: title
		},
		success: function(data){
			if(data.status != false){
				if($("#box_player").show()){
					$('video, audio').each(function() {
						$(this)[0].player.pause();		  
					});
					$("#music-title").html('Bạn đang nghe bài hát: <span title="' + data.title + '">' + data.title + '<span>');
					$(".playermusic").html(data.source);
				}
			}
		},
		error: function (xhr, ajaxOptions, thrownError) {
			alert('Đã xảy ra lỗi khi lấy dữ liệu.');
		}
	});
	return false;
};

KScript.ajax.deleteCache = function(){
	$.ajax({
		type: "GET",
		url: ROOT + "/index.php?modules=cache&action=delete",
		dataType: "json",
		success: function(data){
			if(data.status != false){
				return true;
			}
		},
		error: function (xhr, status, error) {
			alert('Đã xảy ra lỗi khi xoá cache.');
		}
	});
	return false;
}
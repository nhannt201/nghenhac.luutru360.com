<div class="box span8">
    <!-- Main -->
    <div class="row-fluid">
        <div class="box span12">
            <div class="box-content" style="display: block;">
                GZingMp3 hiện đang chạy thử nghiệm.<br />
				Chức năng:<br />
				<ul>
					<li>Tải và chơi nhạc trực tiếp bằng link:<br />
						<pre>http://mp3.zing.vn/bai-hat/Se-Co-Nguoi-Can-Anh-Cao-Thai-Son-Huong-Tram/ZW6799UA.html</pre>
					</li>
					<li>Tìm và chơi bài hát với chất lượng HQ</li>
					<li>Tải và chơi nhạc trên Bảng xếp hạng</li>
				</ul>
            </div>
        </div>
    </div>
	
	<div id="box_player" class="row-fluid" style="display: none;">
		<div class="box span12">
			<div id="music-title" class="box-header"></div>
			<div class="box-content" style="display: block;">
				<div class="playermusic"></div>
			</div>
		</div>
	</div>
	<!--/Main -->
</div>
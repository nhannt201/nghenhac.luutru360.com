<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<title>Nghe & Tải nhạc Zing Mp3 - GZingMp3</title>
	<meta name="description" content="Nghe nhạc & Tải nhạc mp3, nghe nhac mp3, tai nhac zing, tai nhac mp3" />
	<meta name="keywords" content="nghe, tai, nhac, nghe nhac, tai nhac, zing mp3, nghe nhac mp3, tai nhac mp3" />
    <base href="<?php echo SITEURL;?>/" /><!--[if IE]></base><![endif]-->
	<link rel="stylesheet" type="text/css" href="public/themes/css/bootstrap.min.css" media="screen">
	<link rel="stylesheet" type="text/css" href="public/themes/css/style.css">
	<!-- Load Javascript -->
    <script type="text/javascript">
        var ROOT = '<?php echo SITEURL;?>';
    </script>
</head>
<body>
<!-- Modal -->
<div id="modal_delete_cache" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="cacheModalLabel" aria-hidden="true">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="cacheModalLabel">Xoá cache</h3>
	</div>
	<div class="modal-body">
		<p>Đã xoá thành công.</p>
	</div>
</div>
<div class="navbar navbar-default navbar-fixed-top" role="navigation">
	<div class="navbar-inner">
    	<div class="container">
			<div class="nav-collapse collapse">
				<ul class="nav">
					<li class="active">
						<a href="javascript:;"><i class="icon-home"></i> Trang chủ</a>
					</li>
					<li>
						<a title="Làm sạch hệ thống" href="#modal_delete_cache" data-toggle="modal" id="delete_cache" onclick="KScript.ajax.deleteCache();"><i class="icon-refresh"></i> Xoá cache</a>
					</li>
				</ul>
				<form class="navbar-search pull-left" role="search" onSubmit="_submit(); return false;">
					<div class="form-group">
						<div class="input-prepend input-append">
						<input type="hidden" id="txtType" />
						<span class="add-on"><i class="icon-music"></i></span>
						<input type="text" id="txtQuery" class="txtInputMusic form-control span6" placeholder="Tìm kiếm" autofocus="required" />
						<button type="button" id="txtGet" class="txtButtonMusic btn btn-primary"><i class="icon-search"></i> Tìm kiếm</button>
						</div>
					</div>
				</form>
			</div><!--/.nav-collapse -->
        </div>
    </div>
</div>
<div class="container-fluid" id="content">
	<div class="row-fluid">
        <?php require_once $blockFile;?>
		
		<div class="box span4">
			<!-- Main -->
			<div id="box_search" class="row-fluid" style="display: none;">
				<div class="box span12">
					<div id="search-title" class="box-header"></div>
					<div class="box-content" style="display: block;">
						<ul class="item_search"></ul>
					</div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="box span12">
					<div class="box-content" style="display: block;">
						<div class="tabbable">
							<ul class="nav nav-tabs">
								<li class="active"><a href="#bxh_vietnam" data-toggle="tab">Việt Nam</a></li>
								<li><a href="#bxh_aumy" data-toggle="tab">Âu Mỹ</a></li>
								<li><a href="#bxh_hanquoc" data-toggle="tab">Hàn Quốc</a></li>
							</ul>
							<div class="tab-content">
								<div class="tab-pane active" id="bxh_vietnam">
									<ul class="listbxh_vietnam"></ul>
								</div>
								<div class="tab-pane" id="bxh_aumy">
									<ul class="listbxh_aumy"></ul>
								</div>
								<div class="tab-pane" id="bxh_hanquoc">
									<ul class="listbxh_hanquoc"></ul>
								</div>
							</div>
						</div>
					</div>
				</div><!--/span-->
			</div>
			<!--/Main -->
		</div>
    </div>
    <footer>
		<hr />
    	<p class="text-info text-left span6">
			Copyright &copy; <?php echo date('Y');?> by Killer.<br />
			Powered by GZingMp3 Fixed ; &copy; <?php echo date('Y');?> J2Team, Inc. 
		</p>
    	<p class="text-info text-right span6">Thank for <a href="http://junookyo.blogspot.com/" title="Juno_okyo's Blog" target="_blank">Juno_okyo</a> share template.</p>
    </footer>
</div>
<script type="text/javascript" src="public/themes/js/jquery.js"></script>
<script type="text/javascript" src="public/themes/js/bootstrap.min.js"></script>
<script type="text/javascript" src="public/themes/js/kscript.js"></script>
<script type="text/javascript" src="public/themes/js/main.js"></script>
</body>
</html>
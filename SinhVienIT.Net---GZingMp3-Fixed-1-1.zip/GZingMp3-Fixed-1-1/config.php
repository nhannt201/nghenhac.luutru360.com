<?php defined('K_SEC') or die('No direct script access.');

$rootDir = dirname($_SERVER['SCRIPT_NAME']);
$rootDir = str_replace('//', '/', $rootDir);

if($rootDir != '/'){
	$siteUrl = 'http' . ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $rootDir;
}else{
	$siteUrl = 'http' . ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 's' : '') . '://' . $_SERVER['HTTP_HOST'];
}

define('SITEURL', $siteUrl);

$config = array();

//Config cache time
$config['cache_time'] = 43200;

$config['is_curl'] = true;
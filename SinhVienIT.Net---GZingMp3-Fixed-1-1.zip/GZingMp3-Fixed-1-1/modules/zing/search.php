<?php defined('K_SEC') or die('No direct script access.');

$query = isset($_POST['query']) ? $_POST['query'] : '';

if($query != ''){
	require_once LIB_DIR . 'class.cache'. EXT;
	require_once LIB_DIR . 'class.zing'. EXT;
	
	$zing = new Zing;
	
	$zing->_query = str_replace(' ','+',$query);
	$result = array();
	$result['status'] = true;
	$result['title'] = $query;
	$_searchList = K_Cache::instance()->get($query);
	if(empty($_searchList)){
		$_searchList = $zing->_getSearch();
		K_Cache::instance()->set($query,$_searchList,$config['cache_time']);
	}
	$result['source'] = $_searchList;
	
	header('Content-type: text/json');
	header('Content-type: application/json');
	
	echo json_encode($result);
	exit;
}
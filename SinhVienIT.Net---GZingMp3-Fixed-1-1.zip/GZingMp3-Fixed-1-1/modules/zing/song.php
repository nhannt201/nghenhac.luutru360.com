<?php defined('K_SEC') or die('No direct script access.');

header('Content-type: text/json');
header('Content-type: application/json');

$type = isset($_GET['type']) ? $_GET['type'] : '';

if($type == 'bxh'){
	require_once LIB_DIR . 'class.cache'. EXT;
	$_bxh = K_Cache::instance()->get('bxh');
	if(empty($_bxh)){
		require_once LIB_DIR . 'class.zing'. EXT;
		$zing = new Zing;
		$_bxh = array(
			'status' => true,
			'vietnam' => $zing->_getListBXH('vietnam'),
			'aumy' => $zing->_getListBXH('aumy'),
			'hanquoc' => $zing->_getListBXH('hanquoc')
		);
		K_Cache::instance()->set('bxh',$_bxh,$config['cache_time']);
	}
	echo json_encode($_bxh);
	exit;
}elseif($type == 'play_song'){
	$songNameID = isset($_POST['name_id']) ? $_POST['name_id'] : '';
	$songTitle = isset($_POST['title']) ? $_POST['title'] : '';
	
	if($songNameID != '' && $songTitle != ''){
		require_once LIB_DIR . 'class.encryptZingID'. EXT;
		$encryptZing = new Encrypt_ZingID;
		$encryptZing->_ID = $songNameID[1];
		
		$songDownload = array();
		$songDownload[128] = 'http://mp3.zing.vn/html5/song/'.$encryptZing->_getEncryptedID();
		$songDownload[320] = 'http://mp3.zing.vn/download/vip/song/'.$songNameID[1];

		$result = array();
		$result['status'] = true;
		$result['title'] = subChar($songTitle,70);
		$result['source'] = '
			<script src="public/player/js/mediaelement-and-player.min.js"></script>
			<link rel="stylesheet" href="public/player/css/mediaelementplayer.min.css" />
			<audio id="player" src="'.$songDownload[128].'" type="audio/mp3" controls="controls" preload="none" autoplay>Your browser does not support the audio element.</audio>
			<script type="text/javascript">
				$("audio,video").mediaelementplayer({
					audioWidth: 620,
					startVolume: 0.8,
					loop: true,
					alwaysShowHours: true,
					enableKeyboard: true,
					pauseOtherPlayers: true,
				});
			</script>
			<br />
			<div class="btn-group">
				<button class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
					Tải nhạc
					<span class="caret"></span>
				</button>
				<ul class="dropdown-menu">
					<li><a href="'.$songDownload[128].'" target="_blank">Tải nhạc 128kbps</a></li>
					<li><a href="'.$songDownload[320].'" target="_blank">Tải nhạc 320kbps</a></li>
				</ul>
			</div>
		';
		
		echo json_encode($result);
		exit;
	}
}elseif($type == 'get'){
	$txtLink = isset($_POST['link']) ? $_POST['link'] : '';
	
	if($txtLink != ''){
		$songID = explode('.',$txtLink[5]);
		$songID = $songID[0];
		
		require_once LIB_DIR . 'class.encryptZingID'. EXT;
		require_once LIB_DIR . 'class.zing'. EXT;
		
		$encryptZing = new Encrypt_ZingID;
		$zing = new Zing;
		$encryptZing->_ID = $songID;
		$EncryptID = $encryptZing->_getEncryptedID();
		
		$songTitle = $zing->_getSongTitle($EncryptID);

		
		$songDownload = array();
		$songDownload[128] = 'http://mp3.zing.vn/html5/song/'.$EncryptID;
		$songDownload[320] = 'http://mp3.zing.vn/download/vip/song/'.$songID;

		$result = array();
		$result['status'] = true;
		$result['title'] = subChar($songTitle,70);
		$result['source'] = '
			<script src="public/player/js/mediaelement-and-player.min.js"></script>
			<link rel="stylesheet" href="public/player/css/mediaelementplayer.min.css" />
			<audio id="player" src="'.$songDownload[128].'" type="audio/mp3" controls="controls" preload="none" autoplay>Your browser does not support the audio element.</audio>
			<script type="text/javascript">
				$("audio").mediaelementplayer({
					audioWidth: 620,
					startVolume: 0.8,
					loop: true,
					alwaysShowHours: true,
					enableKeyboard: true,
					pauseOtherPlayers: true,
				});
			</script>
			<br />
			<div class="btn-group">
				<button class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
					Tải nhạc
					<span class="caret"></span>
				</button>
				<ul class="dropdown-menu">
					<li><a href="'.$songDownload[128].'" target="_blank">Tải nhạc 128kbps</a></li>
					<li><a href="'.$songDownload[320].'" target="_blank">Tải nhạc 320kbps</a></li>
				</ul>
			</div>
		';
		
		echo json_encode($result);
		exit;
	}
}
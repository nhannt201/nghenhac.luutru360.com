<?php defined('K_SEC') or die('No direct script access.');


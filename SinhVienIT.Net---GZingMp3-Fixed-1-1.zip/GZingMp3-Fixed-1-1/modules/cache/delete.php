<?php defined('K_SEC') or die('No direct script access.');

require_once LIB_DIR . 'class.cache'. EXT;

K_Cache::instance()->delete_all();

$result = array(
	'status' => true,
);

header('Content-type: text/json');
header('Content-type: application/json');
echo json_encode($_bxh);
exit;